<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /widget_allow_messages_from_community.php was not found on this server.</p>
<hr>
<address>Apache/2.2.22 (@<a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="bbe9fef7fefae8fefb">[email&#160;protected]</a>) Server at sonmay.ru Port 80</address>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script></body></html>
